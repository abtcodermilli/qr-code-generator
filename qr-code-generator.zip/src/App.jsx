import { useState, useEffect } from 'react';
import { QRCodeCanvas } from 'qrcode.react';
import { 
  Home, Clock, Star, Settings, Link, Type, Mail, Phone, Wifi, 
  ArrowRight, Download, Code, Copy, Bookmark, RotateCcw,
  CheckCircle, ChevronRight, Moon, Sun, User, Heart, Code2, Globe,
  Sparkles, SlidersHorizontal, Image as ImageIcon
} from 'lucide-react';
import './App.css';

const QR_TYPES = [
  { id: 'URL', label: 'URL', icon: Link },
  { id: 'Text', label: 'Text', icon: Type },
  { id: 'Email', label: 'Email', icon: Mail },
  { id: 'Phone', label: 'Phone', icon: Phone },
  { id: 'WiFi', label: 'Wi-Fi', icon: Wifi },
];

const PRESETS = [
  { name: 'Classic', fg: '#000000', bg: '#ffffff', id: 'classic' },
  { name: 'Gradient', fg: '#6366F1', bg: '#ffffff', id: 'gradient' },
  { name: 'Sunset', fg: '#F59E0B', bg: '#FEF3C7', id: 'sunset' },
  { name: 'Dark', fg: '#38BDF8', bg: '#0B0F19', id: 'dark' },
];

function App() {
  const [qrType, setQrType] = useState('URL');
  const [urlText, setUrlText] = useState('');
  const [plainText, setPlainText] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [wifiSSID, setWifiSSID] = useState('');
  const [wifiPassword, setWifiPassword] = useState('');

  const [size, setSize] = useState(300);
  const [fgColor, setFgColor] = useState('#6366F1');
  const [bgColor, setBgColor] = useState('#FFFFFF');
  const [errorLevel, setErrorLevel] = useState('H');
  const [margin, setMargin] = useState(4);
  const [selectedPreset, setSelectedPreset] = useState('Modern');

  const [recent, setRecent] = useState(() => {
    try {
      const saved = localStorage.getItem('qrgenie_recent');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [error, setError] = useState('');
  const [warning, setWarning] = useState('');
  const [copied, setCopied] = useState(false);

  const getQRValue = () => {
    switch (qrType) {
      case 'URL': return urlText.trim();
      case 'Text': return plainText.trim();
      case 'Email': return email.trim() ? `mailto:${email.trim()}` : '';
      case 'Phone': return phone.trim() ? `tel:${phone.trim()}` : '';
      case 'WiFi': return wifiSSID.trim() ? `WIFI:T:WPA;S:${wifiSSID.trim()};P:${wifiPassword};;` : '';
      default: return '';
    }
  };

  const qrValue = getQRValue();

  useEffect(() => {
    if (!qrValue) {
      setError('');
      return;
    }
    if (qrType === 'URL') {
      const looksValid = /^https?:\/\/.+\..+/.test(urlText.trim());
      setError(looksValid ? '' : 'Enter a valid URL starting with http:// or https://');
    } else if (qrType === 'Email') {
      const looksValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim());
      setError(looksValid ? '' : 'Enter a valid email address');
    } else if (qrType === 'Phone') {
      const looksValid = /^[+\d][\d\s-]{6,}$/.test(phone.trim());
      setError(looksValid ? '' : 'Enter a valid phone number');
    } else {
      setError('');
    }
  }, [qrType, urlText, email, phone, qrValue]);

  useEffect(() => {
    if (!qrValue) {
      setWarning('');
      return;
    }
    const warnings = [];
    if (errorLevel === 'L' && qrValue.length > 60) warnings.push('Low error correction with long content.');
    if (margin < 2) warnings.push('Low margin may affect scannability.');
    if (fgColor.toLowerCase() === bgColor.toLowerCase()) warnings.push('Foreground and background match.');
    
    // Check contrast (very basic)
    const getLuma = (c) => {
      const hex = c.replace('#', '');
      const r = parseInt(hex.substr(0, 2), 16);
      const g = parseInt(hex.substr(2, 2), 16);
      const b = parseInt(hex.substr(4, 2), 16);
      return 0.2126 * r + 0.7152 * g + 0.0722 * b;
    };
    if (fgColor.length === 7 && bgColor.length === 7) {
      const diff = Math.abs(getLuma(fgColor) - getLuma(bgColor));
      if (diff < 40) warnings.push('Low color contrast.');
    }

    setWarning(warnings.join(' '));
  }, [qrValue, errorLevel, margin, fgColor, bgColor]);

  const handleDownload = () => {
    const canvas = document.getElementById('qr-canvas');
    if (!canvas) return;
    const url = canvas.toDataURL('image/png');
    const link = document.createElement('a');
    link.href = url;
    link.download = 'QRGenie.png';
    link.click();
    saveToRecent();
  };

  const handleDownloadSVG = () => {
    const canvas = document.getElementById('qr-canvas');
    if (!canvas) return;
    const svgData = `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}"><image href="${canvas.toDataURL('image/png')}" width="${size}" height="${size}"/></svg>`;
    const blob = new Blob([svgData], { type: 'image/svg+xml' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'QRGenie.svg';
    link.click();
    URL.revokeObjectURL(url);
    saveToRecent();
  };

  const saveToRecent = () => {
    if (!qrValue || error) return;
    const entry = { type: qrType, value: qrValue, date: new Date().toISOString() };
    const updated = [entry, ...recent.filter((r) => r.value !== qrValue)].slice(0, 6);
    setRecent(updated);
    localStorage.setItem('qrgenie_recent', JSON.stringify(updated));
  };

  const handleCopyLink = async () => {
    if (!qrValue) return;
    try {
      await navigator.clipboard.writeText(qrValue);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      setCopied(false);
    }
  };

  const handleReset = () => {
    setSize(300);
    setFgColor('#6366F1');
    setBgColor('#FFFFFF');
    setErrorLevel('H');
    setMargin(4);
    setSelectedPreset('Modern');
  };

  const applyPreset = (preset) => {
    setFgColor(preset.fg);
    setBgColor(preset.bg);
  };

  const loadRecent = (item) => {
    setQrType(item.type);
    if (item.type === 'URL') setUrlText(item.value);
    if (item.type === 'Text') setPlainText(item.value);
    if (item.type === 'Email') setEmail(item.value.replace('mailto:', ''));
    if (item.type === 'Phone') setPhone(item.value.replace('tel:', ''));
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const reliabilityScore = warning ? 75 : 98;
  const isReliable = reliabilityScore > 90;

  // Tiny inline SVG for the logo
  const logoUrl = "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%236366F1'><path d='M12 2L14 9L21 11L14 13L12 20L10 13L3 11L10 9Z'/></svg>";

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="sidebar-header">
          <div className="logo-container">
            <Sparkles className="logo-icon" size={24} />
            <span className="logo-text">QRGenie</span>
          </div>
          <p className="subtitle">More than just a QR code</p>
        </div>

        <nav className="nav-menu">
          <a href="#" className="nav-item active">
            <Home size={18} />
            Generate QR
          </a>
          <a href="#recent-section" className="nav-item">
            <Clock size={18} />
            Recent QR Codes
          </a>
          <a href="#" className="nav-item">
            <Star size={18} />
            Presets
          </a>
          <a href="#" className="nav-item">
            <Settings size={18} />
            Settings
          </a>
        </nav>

        <div className="promo-card">
          <div className="promo-content">
            <Sparkles size={16} className="promo-icon" />
            <h3>Create<br/>Scan<br/>Share</h3>
            <p>Turn your ideas into<br/>QR codes in seconds.</p>
          </div>
          <div className="promo-graphic">
            <div className="promo-phone">
              <div className="promo-qr"></div>
            </div>
          </div>
        </div>

        <div className="quick-links">
          <h4>Quick Links</h4>
          <a href="https://www.linkedin.com/in/ankur-bikram-thapa-02a526380" target="_blank" rel="noreferrer">
            <User size={16} /> LinkedIn
          </a>
          <a href="https://github.com/abtcodermilli" target="_blank" rel="noreferrer">
            <Code2 size={16} /> GitHub
          </a>
        </div>

        <div className="sidebar-footer">
          <Heart size={14} className="heart-icon" />
          <p>Built with passion<br/>for a better tomorrow</p>
        </div>
      </aside>

      <main className="main-content">
        <header className="top-header">
          <div className="header-text">
            <h1>Turn Your Ideas Into<br/><span className="text-gradient">QR Codes</span></h1>
            <p>Generate, customize and download QR codes for URLs, text, emails, phone numbers, Wi-Fi and more — all in your browser.</p>
          </div>
          <div className="header-actions">
            <div className="theme-toggle">
              <Sun size={16} className="active" />
              <Moon size={16} />
            </div>
            <div className="avatar">A</div>
          </div>
        </header>

        <div className="content-grid">
          <div className="left-column">
            
            {/* Step 1 */}
            <section className="card form-section">
              <div className="step-header">
                <span className="step-badge">1</span>
                <div>
                  <h2>Choose QR Type</h2>
                  <p>Select the type of data you want to encode</p>
                </div>
              </div>
              <div className="type-grid">
                {QR_TYPES.map((type) => {
                  const Icon = type.icon;
                  return (
                    <button
                      key={type.id}
                      className={`type-btn ${qrType === type.id ? 'active' : ''}`}
                      onClick={() => setQrType(type.id)}
                    >
                      <Icon size={20} />
                      <span>{type.label}</span>
                    </button>
                  );
                })}
              </div>
            </section>

            {/* Step 2 */}
            <section className="card form-section">
              <div className="step-header">
                <span className="step-badge">2</span>
                <div>
                  <h2>Enter Your Information</h2>
                  <p>Add your {qrType} below</p>
                </div>
              </div>
              <div className="input-group">
                <div className="input-icon-wrapper">
                  {(() => {
                    const ActiveIcon = QR_TYPES.find(t => t.id === qrType)?.icon;
                    return ActiveIcon ? <ActiveIcon size={18} className="input-icon" /> : null;
                  })()}
                </div>
                
                {qrType === 'URL' && (
                  <input type="text" placeholder="https://www.example.com" value={urlText} onChange={(e) => setUrlText(e.target.value)} />
                )}
                {qrType === 'Text' && (
                  <input type="text" placeholder="Enter your text here..." value={plainText} onChange={(e) => setPlainText(e.target.value)} />
                )}
                {qrType === 'Email' && (
                  <input type="email" placeholder="example@email.com" value={email} onChange={(e) => setEmail(e.target.value)} />
                )}
                {qrType === 'Phone' && (
                  <input type="tel" placeholder="+1 234 567 890" value={phone} onChange={(e) => setPhone(e.target.value)} />
                )}
                {qrType === 'WiFi' && (
                  <div className="wifi-inputs">
                    <input type="text" placeholder="Network SSID" value={wifiSSID} onChange={(e) => setWifiSSID(e.target.value)} />
                    <input type="password" placeholder="Password" value={wifiPassword} onChange={(e) => setWifiPassword(e.target.value)} />
                  </div>
                )}
                <button className="input-submit-btn"><ArrowRight size={16} /></button>
              </div>
              {error && <p className="error-text">{error}</p>}
            </section>

            {/* Step 3 */}
            <section className="card form-section">
              <div className="step-header">
                <span className="step-badge">3</span>
                <div>
                  <h2>Customize Your QR Code</h2>
                  <p>Make it yours. Adjust the style, size and more.</p>
                </div>
              </div>

              <div className="customization-grid">
                <div className="control-group full-width">
                  <div className="control-header">
                    <label>Size</label>
                    <span className="value-label">{size} px</span>
                  </div>
                  <input type="range" min="100" max="1000" value={size} onChange={(e) => setSize(Number(e.target.value))} className="slider" />
                </div>

                <div className="control-group">
                  <label>Foreground Color</label>
                  <div className="color-picker-wrapper">
                    <input type="color" value={fgColor} onChange={(e) => setFgColor(e.target.value)} />
                    <span className="hex-val">{fgColor.toUpperCase()}</span>
                    <ChevronRight size={16} className="dropdown-icon" />
                  </div>
                </div>

                <div className="control-group">
                  <label>Background Color</label>
                  <div className="color-picker-wrapper">
                    <input type="color" value={bgColor} onChange={(e) => setBgColor(e.target.value)} />
                    <span className="hex-val">{bgColor.toUpperCase()}</span>
                    <ChevronRight size={16} className="dropdown-icon" />
                  </div>
                </div>

                <div className="control-group">
                  <label>Error Correction Level</label>
                  <div className="select-wrapper">
                    <select value={errorLevel} onChange={(e) => setErrorLevel(e.target.value)}>
                      <option value="L">Low</option>
                      <option value="M">Medium</option>
                      <option value="Q">Quartile</option>
                      <option value="H">High (Best Quality)</option>
                    </select>
                    <ChevronRight size={16} className="dropdown-icon" />
                  </div>
                </div>

                <div className="control-group">
                  <label>Margin / Padding</label>
                  <div className="select-wrapper">
                    <select value={margin} onChange={(e) => setMargin(Number(e.target.value))}>
                      <option value="0">0 (None)</option>
                      <option value="2">2 (Small)</option>
                      <option value="4">4 (Default)</option>
                      <option value="8">8 (Large)</option>
                    </select>
                    <ChevronRight size={16} className="dropdown-icon" />
                  </div>
                </div>

                <div className="control-group full-width">
                  <button className="advanced-btn">
                    <SlidersHorizontal size={16} />
                    Advanced Options
                    <ChevronRight size={16} className="dropdown-icon ml-auto" />
                  </button>
                </div>
              </div>

              <button className="generate-btn" disabled={!qrValue || !!error}>
                <Sparkles size={18} />
                Generate QR Code <ArrowRight size={18} />
              </button>
            </section>

            {/* Recent Section */}
            {recent.length > 0 && (
              <section className="recent-section" id="recent-section">
                <div className="section-header">
                  <div className="flex items-center gap-2">
                    <Clock size={16} />
                    <h3>Recent QR Codes</h3>
                  </div>
                  <a href="#" className="view-all">View all <ArrowRight size={14} /></a>
                </div>
                <div className="recent-grid">
                  {recent.map((item, i) => (
                    <div key={i} className="recent-card" onClick={() => loadRecent(item)}>
                      <div className="recent-qr-thumb">
                        <QRCodeCanvas value={item.value} size={40} marginSize={1} fgColor="#6366F1" />
                      </div>
                      <div className="recent-info">
                        <h4>{item.type} {item.type === 'URL' && 'Link'}</h4>
                        <span className="time">Just now</span>
                      </div>
                    </div>
                  ))}
                </div>
              </section>
            )}

          </div>

          <div className="right-column">
            
            {/* Live Preview Card */}
            <div className="card preview-card">
              <div className="card-header">
                <div className="flex items-center gap-2">
                  <ImageIcon size={16} className="text-purple-400" />
                  <h3>Live Preview</h3>
                </div>
                <span className="badge badge-green">
                  <span className="dot"></span> Real-time updates
                </span>
              </div>
              
              <div className="qr-display-area">
                <div className="qr-container">
                  {qrValue && !error ? (
                    <QRCodeCanvas
                      id="qr-canvas"
                      value={qrValue}
                      size={200}
                      fgColor={fgColor}
                      bgColor={bgColor}
                      level={errorLevel}
                      marginSize={margin}
                      imageSettings={{
                        src: logoUrl,
                        height: 40,
                        width: 40,
                        excavate: true,
                      }}
                      style={{ width: '100%', height: 'auto', borderRadius: '12px' }}
                    />
                  ) : (
                    <div className="qr-placeholder">
                      <Sparkles size={32} />
                      <p>Enter data to generate</p>
                    </div>
                  )}
                </div>
              </div>

              <div className="download-actions">
                <button className="btn btn-primary" onClick={handleDownload} disabled={!qrValue || !!error}>
                  <Download size={16} /> Download PNG
                </button>
                <button className="btn btn-secondary" onClick={handleDownloadSVG} disabled={!qrValue || !!error}>
                  <Code size={16} /> Download SVG
                </button>
              </div>

              <div className="util-actions">
                <button className="btn-util" onClick={handleCopyLink} disabled={!qrValue}>
                  <Copy size={16} />
                  <span>{copied ? 'Copied' : 'Copy Link'}</span>
                </button>
                <button className="btn-util" onClick={saveToRecent} disabled={!qrValue || !!error}>
                  <Bookmark size={16} />
                  <span>Save to Recent</span>
                </button>
                <button className="btn-util" onClick={handleReset}>
                  <RotateCcw size={16} />
                  <span>Reset</span>
                </button>
              </div>
            </div>

            {/* Scan Reliability Card */}
            {qrValue && !error && (
              <div className="card reliability-card">
                <div className="card-header">
                  <div className="flex items-center gap-2">
                    <CheckCircle size={16} className="text-green-400" />
                    <h3>Scan Reliability</h3>
                  </div>
                  <span className={`badge ${isReliable ? 'badge-green' : 'badge-yellow'}`}>
                    {isReliable ? 'Excellent' : 'Fair'}
                  </span>
                </div>
                
                <div className="reliability-content">
                  <div className="score-ring" style={{ '--score': `${reliabilityScore}%`, '--color': isReliable ? '#10B981' : '#F59E0B' }}>
                    <svg viewBox="0 0 36 36" className="circular-chart">
                      <path className="circle-bg"
                        d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
                      <path className="circle"
                        strokeDasharray={`${reliabilityScore}, 100`}
                        d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
                    </svg>
                    <div className="percentage">{reliabilityScore}%</div>
                  </div>
                  <div className="checklist">
                    <p className="checklist-title">This QR code is highly scannable!</p>
                    <ul>
                      <li><CheckCircle size={14} className="check-icon" /> Good contrast ratio</li>
                      <li><CheckCircle size={14} className="check-icon" /> Proper size</li>
                      <li><CheckCircle size={14} className="check-icon" /> Error correction: {errorLevel}</li>
                      <li><CheckCircle size={14} className="check-icon" /> Perfect for all devices</li>
                    </ul>
                    {warning && <p className="warning-text mt-2 text-yellow-400 text-xs">⚠️ {warning}</p>}
                  </div>
                </div>
              </div>
            )}

            {/* Quick Presets Card */}
            <div className="card presets-card">
              <div className="card-header">
                <div className="flex items-center gap-2">
                  <Star size={16} />
                  <h3>Quick Presets</h3>
                </div>
                <a href="#" className="view-all">View all <ArrowRight size={14} /></a>
              </div>
              
              <div className="presets-grid">
                {PRESETS.map(preset => (
                  <button key={preset.id} className="preset-item" onClick={() => applyPreset(preset)}>
                    <div className="preset-thumb">
                      <QRCodeCanvas value="https://example.com" size={40} fgColor={preset.fg} bgColor={preset.bg} marginSize={1} />
                    </div>
                    <span>{preset.name}</span>
                  </button>
                ))}
              </div>
            </div>

          </div>
        </div>
      </main>
    </div>
  );
}

export default App;